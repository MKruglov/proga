#include "Header.h"
#include "iostream"

using namespace std;

surface::surface()
{
	quantity = 0;
}

void surface::putPoint()
{
	cout << "Input the coordinates of the point: " << endl;
	cin >> pointsx[quantity];
	cin >> pointsy[quantity];
	quantity++;
}

void surface::look()
{
	for (int i = 0; i < quantity; i++)
	{
		cout << pointsx[i] << " " << pointsy[i] << endl;
	}
}

void surface::getPoint(int n)
{
	cout << pointsx[n-1] << " " << pointsy[n-1] << endl;

}

void surface::editPoint(int n)
{
	cin >> pointsx[n-1];
	cin >> pointsy[n-1];
}

void surface::deletePoint(int n)
{
	for (int i = n - 1; i < quantity - 1; i++)
	{
		pointsx[i] = pointsx[i+1];
		pointsy[i] = pointsy[i+1];

	}
	quantity--;
}

void surface::pointsInArea(int x1, int y1, int x2, int y2)
{
	
		for (int i = 0; i < quantity; i++)
		{
			if ((pointsx[i] > ((x1 < x2) ? x1 : x2)) && (pointsx[i] < ((x1 > x2) ? x1 : x2)) &&
				(pointsy[i] >((y1 < y2) ? y1 : y2)) && (pointsy[i] < ((y1 > y2) ? y1 : y2)))
			{
				cout << pointsx[i] << " " << pointsy[i] << endl;
			}

		}
}
