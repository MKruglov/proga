#pragma once


class surface
{
	double pointsx[100];
	double pointsy[100];
public:
	int quantity;
	surface();
	void putPoint();
	void look();
	void getPoint(int);
	void editPoint(int);
	void deletePoint(int);
	void pointsInArea(int, int, int, int);
};