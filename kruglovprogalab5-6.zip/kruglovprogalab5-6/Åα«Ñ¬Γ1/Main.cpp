#include "Header.h"
#include "iostream"

using namespace std;

int main() 
{
	int n;
	surface surf;
	
	cout << "Write, how much points do you want to put in:" << endl;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		surf.putPoint();
	}
	surf.look();

cout << "Write number of the point you wanna see:" << endl;
	cin >> n;
	surf.getPoint(n);
	cout << endl;

	cout << "Write number of the point you wanna edit:" << endl;
	cin >> n;
	surf.editPoint(n);
	cout << endl;
    

	cout << "Write number of the point you wanna delete:" << endl;
	cin >> n;
	surf.deletePoint(n);
	cout << endl;

	int x1, y1, x2, y2;
    surf.look();
	 
	cout << "Write coordinats of points rectangle:" << endl;
	cin >> x1 >> y1 >> x2 >> y2;
	surf.pointsInArea(x1, y1, x2, y2);
    system("pause");
	return 0;
}